int main() {
	cout<<"\n Hello world!"<<endl;

	//check1
	for(int i=0;i<10;i++)
		printf("%s\n",i);
	//check2
	return 0;
}
