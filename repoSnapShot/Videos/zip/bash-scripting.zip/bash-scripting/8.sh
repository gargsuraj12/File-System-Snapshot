#!/bin/sh

# Use of Logical operators && and || - Conditional execution

if [ $# -ne 2 ] ; then
	echo "Invalid Number of arguments passed"
	exit 2
fi

#Remember '/dev/null' file ? its a Black hole !!!
grep "$1" $2 2> /dev/null && echo "Pattern found"

#Remember '2>' ?

# 0> : for standard input
# 1> : for standard output
# 2> : for standard error

grep $2 "$1" 2> /dev/null || echo "Pattern Not found"
# error in first line but redirects that error to the file

# So in || command2 executes only if Command1 is unsuccessful


exit 0 #Always use me buddy!!!!