#!/bin/bash

# How to take input from User

echo -e "Enter the word to be searched : \cacha" # -e : enable backslash interpretation
										         # -E : disable backslash interpretation
										         # -c : prints upto \c (stops next line from printing)
read word
echo -e "Enter the file name : \c"
read fileName

grep $word $fileName