#!/bin/bash

# demo of the for loop construct 

for i in 1 2 3 4 5
do                    
	echo $i 
done


# We can specify ranges also 

for i in {1..20}
do
	echo $i
done


for ((i=1;i<=5;i++))
do
	echo -e $i" \c"
done



for i in `seq  1 2 20`
do
	echo $i
done



for i in `seq  20 -2 1`
do
	echo $i
done



exit 0

