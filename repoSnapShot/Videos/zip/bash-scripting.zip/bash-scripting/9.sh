# Basics:
# - No boundary checking for indices
# - Negative indices correspond to elements from reverse of the array
# - printf is available upto first space encountered
# - $RANDOM - gives a random number




# 1. Declaring an Array and Assigning values

#In bash, array is created automatically when a variable is used in the format like,

echo '----------------- 1 starts -----------------'
name[index]="str"
echo ${name[@]}

#name is any name for an array
#index could be any number or expression
#that must evaluate to a number greater than
#or equal to zero.You can declare an explicit array
#using 'declare -a arrayname'

#! /bin/bash
Unix[0]='Debian'
Unix[1]='Red hat'
Unix[2]='Ubuntu'
Unix[3]='Suse'

echo ${Unix[1]}
# echo ${Unix[-2]}
echo '----------------- 1 ends -----------------'































#2. Initializing an array during declaration


# Syntax:
# arrayname=(element1 element2 element3)

#If the elements has the white space character, enclose it with in a quotes.


#! /bin/bash
echo '----------------- 2 starts -----------------'
Unix=('Debian' 'Red hat' 'Suse' 'Fedora');
echo '----------------- 2 ends -----------------'

































# 3. Print the Whole Bash Array
echo '----------------- 3 starts -----------------'

echo ${Unix[@]}
echo ${Unix}	# Similar to echo ${Unix[0]}

echo '----------------- 3 ends -----------------'































# 4. Length of the Bash Array

# Syntax:
# ${#arrayname[@]}




echo '----------------- 4 starts -----------------'
Unix=('Debian' 'Red hat' 'Suse' 'Fedora');
echo ${#Unix[@]} #Number of elements in the array
echo '----------------- 4 ends -----------------'



































# 5. Length of the nth Element in an Array

# ${#arrayname[n]} should give the length of the nth element in an array.




#! /bin/bash
echo '----------------- 5 starts -----------------'
Unix[0]='Debian'
Unix[1]='Red hat'
Unix[2]='Ubuntu'
Unix[3]='Suse'

echo ${#Unix[3]} # length of the element located at index 3 i.e Suse
echo ${#Unix}  #Number of characters in the first element of the array.i.e Debian

# echo '-----------------'
# for i in "${Unix[@]}"
# do
# 	echo "$i"
# done
# echo '-----------------'
echo '----------------- 5 ends -----------------'
































# 6. Extraction by offset and length for an array

echo '----------------- 6 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
echo ${Unix[@]:3:2} #  :n:m - goes from nth upto m more indices
echo ${Unix[@]:3:20}" 'This is the end ;)' !" #  :n:m - goes from nth to end if m exceeds ${#array[@]} i.e. length of the array
echo ${Unix[@]:3}   #  :n - goes from nth to end index
echo ${Unix[@]::3}  # ::n - goes from 0th to (n-1)th index
echo ${Unix[@]:1:4}  # :m:n - goes from mth to nth index - for the array elements but goes to (n-1)th index for the offset in element itself as shown in 7.

echo '----------------- 6 ends -----------------'
































# 7. Extraction with offset and length, for a particular element of an array

echo '----------------- 7 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
echo ${Unix[2]:0:4} # array_element:m:n - goes from mth to (n-1)th charcter

echo '----------------- 7 ends -----------------'































# 8. Search and Replace in an array elements


echo '----------------- 8 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
echo ${Unix[@]/Ubuntu/SCO Unix}
#	  array/original/replace_with

# Note: it will not change the values in the array

echo '----------------- 8 ends -----------------'




























# 9. Add an element to an existing Bash Array

echo '----------------- 9 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
Unix=("${Unix[@]}" "AIX" "HP-UX")
echo ${Unix[7]}

echo '----------------- 9 ends -----------------'

































# 10. Remove an Element from an Array

# unset is used to remove an element from an array.
# unset will have the same effect as assigning null to an element.

echo '----------------- 10 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');

unset Unix[3]
echo ${Unix[3]}
# echo ${Unix[@]}

echo '----------------- 10 ends -----------------'
































# 11. Copying an Array


echo '----------------- 11 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
Linux=("${Unix[@]}")
echo ${Linux[@]}

echo '----------------- 11 ends -----------------'
































# 12. Concatenation of two Bash Arrays

echo '----------------- 12 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
Shell=('bash' 'csh' 'jsh' 'rsh' 'ksh' 'rc' 'tcsh');

UnixShell=("${Unix[@]}" "${Shell[@]}")
echo ${UnixShell[@]}
echo ${#UnixShell[@]}

echo '----------------- 12 ends -----------------'































# 13. Deleting an Entire Array

echo '----------------- 13 starts -----------------'

Unix=('Debian' 'Red hat' 'Ubuntu' 'Suse' 'Fedora' 'UTS' 'OpenLinux');
Shell=('bash' 'csh' 'jsh' 'rsh' 'ksh' 'rc' 'tcsh');

UnixShell=("${Unix[@]}" "${Shell[@]}")
unset UnixShell
echo ${#UnixShell[@]}
# echo $ {#UnixShell[@]}
# echo ${#kk[@]}
echo '----------------- 13 starts -----------------'
































#14. Load Content of a File into an Array

# You can load the content of the file line by line into an array.

echo '----------------- 14 starts -----------------'

# Example file
# cat 1.sh

echo -e 'Enter filename to load into array: \c'
read f
filecontent=( `cat $f `)

echo "-------- Start reading ---------"
for t in "${filecontent[@]}"
do
echo $t
done
echo "-------- End reading ---------"

echo '----------------- 14 ends -----------------'















